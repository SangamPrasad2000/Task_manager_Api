# Lokis-porfolio-website
# {James Kaloki Personal Portfolio Website}
#### { A simple portfolio giving more about myself.}, {16th 2021}
#### By **{James Kaloki}**
## Description
{This is a porfolio website that can be used to showcase html and css knowledge. }
## Setup/Installation Requirements
* A search engine.
* Windows,Linux and Mac OS.
*
link to live website https://jameskaloki2000.github.io/Lokis-porfolio-website/.

{No installation requirements}
## Known Bugs
{Non-Applicable  }
## Technologies Used
{Technologies used are , HTML,CCS}
## Support and contact details
{contact me @kaloki2012@gmail.com}
### License
*{GNU Affero General Public License v 3.0}*
Copyright (c) {2021} **{James Kaloki,Bedan Maison}**
